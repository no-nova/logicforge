import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Canvas, { View } from './components/Canvas';
import LeftPanel from './components/LeftPanel';
import Inspector from './components/Inspector';
import Toolbar from './components/Toolbar';
import { useEditor, demoDoc } from './lib/store';
import { Doc, Val, nodeSize, simulate } from './lib/circuit';
import { THEMES, applyTheme } from './lib/themes';

export default function App() {
  const ed = useEditor();
  const [themeId, setThemeId] = useState(() => localStorage.getItem('logicforge.theme') || 'blue-dark');
  const [view, setView] = useState<View>({ x: 60, y: 40, z: 1 });
  const [running, setRunning] = useState(true);
  const [tick, setTick] = useState(0);
  const [speed, setSpeed] = useState(8);
  const [wireStyle, setWireStyle] = useState<'curve' | 'ortho'>('curve');
  const [snapOn, setSnapOn] = useState(true);
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const centerRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = THEMES.find((t) => t.id === themeId) ?? THEMES[0];
    applyTheme(t);
    localStorage.setItem('logicforge.theme', themeId);
  }, [themeId]);

  /* ------------------------- simulation loop ------------------------ */
  const hasClock = useMemo(() => ed.doc.nodes.some((n) => n.type === 'CLOCK'), [ed.doc.nodes]);

  useEffect(() => {
    if (!running || !hasClock) return;
    const iv = setInterval(() => setTick((t) => t + 1), Math.max(40, 500 / speed));
    return () => clearInterval(iv);
  }, [running, speed, hasClock]);

  const effTick = hasClock ? tick : 0;
  const sourceValues = useMemo(() => {
    const m = new Map<string, Val>();
    for (const n of ed.doc.nodes) {
      if (n.type === 'INPUT') m.set(n.id, (n.value ?? 0) as Val);
      if (n.type === 'CLOCK') {
        const p = Math.max(2, n.period ?? 12);
        m.set(n.id, (Math.floor(effTick / (p / 2)) % 2 === 0 ? 0 : 1) as Val);
      }
    }
    return m;
  }, [ed.doc.nodes, effTick]);

  const sim = useMemo(() => simulate(ed.doc, ed.doc.defs, sourceValues), [ed.doc, sourceValues]);

  const toggleSwitch = useCallback((id: string) => {
    const n = ed.doc.nodes.find((x) => x.id === id);
    if (!n) return;
    if (n.type === 'INPUT') {
      ed.commit((d) => ({
        ...d, nodes: d.nodes.map((x) => (x.id === id ? { ...x, value: x.value === 1 ? 0 : 1 } : x)),
      }), 'toggle');
    } else if (n.type === 'CLOCK') setRunning((r) => !r);
  }, [ed]);

  /* ---------------------------- viewport ---------------------------- */
  const centerWorld = useCallback(() => {
    const r = centerRef.current?.getBoundingClientRect();
    if (!r) return { x: 0, y: 0 };
    return { x: (r.width / 2 - view.x) / view.z, y: (r.height / 2 - view.y) / view.z };
  }, [view]);

  const fit = useCallback(() => {
    const r = centerRef.current?.getBoundingClientRect();
    if (!r || !ed.doc.nodes.length) { setView({ x: 60, y: 40, z: 1 }); return; }
    let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
    for (const n of ed.doc.nodes) {
      const { w, h } = nodeSize(n, ed.doc.defs);
      x1 = Math.min(x1, n.x - 20); y1 = Math.min(y1, n.y - 20);
      x2 = Math.max(x2, n.x + w + 20); y2 = Math.max(y2, n.y + h + 20);
    }
    const z = Math.min(2, Math.max(0.2, Math.min(r.width / (x2 - x1), r.height / (y2 - y1))));
    setView({ z, x: r.width / 2 - ((x1 + x2) / 2) * z, y: r.height / 2 - ((y1 + y2) / 2) * z });
  }, [ed.doc]);

  /* --------------------------- file actions ------------------------- */
  const exportJson = () => {
    const blob = new Blob([JSON.stringify(ed.doc, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'circuit.logicforge.json';
    a.click();
    URL.revokeObjectURL(a.href);
  };
  const importJson = (f: File) => {
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(String(r.result)) as Doc;
        if (Array.isArray(d.nodes) && Array.isArray(d.wires)) ed.load({ ...d, defs: d.defs ?? [] });
      } catch { /* ignore */ }
    };
    r.readAsText(f);
  };

  /* ----------------------------- hotkeys ---------------------------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? ed.redo() : ed.undo(); }
      else if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); ed.redo(); }
      else if (mod && e.key.toLowerCase() === 'c') ed.copy();
      else if (mod && e.key.toLowerCase() === 'v') ed.paste();
      else if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); ed.duplicateSelected(); }
      else if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); ed.setSelection(ed.doc.nodes.map((n) => n.id)); }
      else if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); exportJson(); }
      else if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); ed.deleteSelected(); }
      else if (e.key.toLowerCase() === 'r') ed.rotateSelected();
      else if (e.key === ' ') { e.preventDefault(); setRunning((r) => !r); }
      else if (e.key.toLowerCase() === 'f') fit();
      else if (e.key === 'Escape') { ed.setSelection([]); ed.setSelectedWires([]); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [ed, fit]);

  const theme = THEMES.find((t) => t.id === themeId) ?? THEMES[0];

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden font-sans text-[var(--text)]"
      style={{ background: 'var(--bg)' }}>
      {/* header */}
      <header className="flex h-12 shrink-0 items-center gap-3 border-b border-[var(--border)] bg-[var(--panel)] px-3">
        <div className="flex items-center gap-2">
          <div className="grid h-7 w-7 place-items-center rounded-md" style={{ background: 'var(--accent)' }}>
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="var(--panel)" strokeWidth={2.2} strokeLinecap="round">
              <path d="M3 8h4l3 8h4l3-8h4" /><circle cx="12" cy="12" r="1.6" fill="var(--panel)" stroke="none" />
            </svg>
          </div>
          <div className="leading-tight">
            <div className="text-[13px] font-bold tracking-tight">LogicForge</div>
            <div className="text-[9px] uppercase tracking-[0.2em] text-[var(--muted)]">digital design sandbox</div>
          </div>
        </div>

        <div className="mx-2 h-6 w-px bg-[var(--border)]" />

        <HBtn onClick={() => { ed.reset(); setTick(0); }}>New</HBtn>
        <HBtn onClick={() => ed.load(demoDoc())}>Sample</HBtn>
        <HBtn onClick={exportJson}>Export</HBtn>
        <HBtn onClick={() => fileRef.current?.click()}>Import</HBtn>
        <input ref={fileRef} type="file" accept="application/json" className="hidden"
          onChange={(e) => e.target.files?.[0] && importJson(e.target.files[0])} />

        <div className="ml-auto flex items-center gap-2">
          <HBtn onClick={() => setLeftOpen(!leftOpen)} active={leftOpen}>▤ Library</HBtn>
          <HBtn onClick={() => setRightOpen(!rightOpen)} active={rightOpen}>Inspector ▤</HBtn>
          <select value={themeId} onChange={(e) => setThemeId(e.target.value)}
            className="h-7 rounded-md border border-[var(--border)] bg-[var(--panel2)] px-2 text-[11px] text-[var(--text)] outline-none">
            {THEMES.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>
      </header>

      {/* body */}
      <div className="flex min-h-0 flex-1">
        {leftOpen && (
          <aside className="w-56 shrink-0 border-r border-[var(--border)] bg-[var(--panel)]">
            <LeftPanel ed={ed} centerWorld={centerWorld} />
          </aside>
        )}

        <main ref={centerRef} className="relative min-w-0 flex-1">
          <Canvas ed={ed} sim={sim} view={view} setView={setView} running={running}
            wireStyle={wireStyle} snapOn={snapOn} onToggleSwitch={toggleSwitch} probeIds={[]} />
          <div className="pointer-events-none absolute left-3 top-3 flex gap-1.5 text-[10px]">
            <Badge>{ed.selection.length ? `${ed.selection.length} selected` : 'no selection'}</Badge>
            {!sim.stable && <Badge warn>oscillation detected</Badge>}
            {!!sim.floating.length && <Badge warn>{sim.floating.length} floating input{sim.floating.length > 1 ? 's' : ''}</Badge>}
            <Badge>{theme.dark ? 'dark' : 'light'} · {wireStyle}</Badge>
          </div>
        </main>

        {rightOpen && (
          <aside className="w-72 shrink-0 border-l border-[var(--border)] bg-[var(--panel)]">
            <Inspector ed={ed} sim={sim} />
          </aside>
        )}
      </div>

      <Toolbar ed={ed} sim={sim} running={running} setRunning={setRunning}
        step={() => setTick((t) => t + 1)} resetSim={() => { setTick(0); setRunning(false); }}
        tick={tick} speed={speed} setSpeed={setSpeed} view={view} setView={setView} fit={fit}
        wireStyle={wireStyle} setWireStyle={setWireStyle} snapOn={snapOn} setSnapOn={setSnapOn} />
    </div>
  );
}

function HBtn({ children, onClick, active }: { children: React.ReactNode; onClick?: () => void; active?: boolean }) {
  return (
    <button onClick={onClick}
      className={`h-7 rounded-md border px-2.5 text-[11px] font-semibold transition active:scale-95 ${
        active ? 'border-[var(--accent)] text-[var(--accent)]' : 'border-[var(--border)] text-[var(--text)] hover:border-[var(--accent)]'
      }`}>{children}</button>
  );
}

function Badge({ children, warn }: { children: React.ReactNode; warn?: boolean }) {
  return (
    <span className="rounded-md border px-2 py-1 font-semibold backdrop-blur"
      style={{
        borderColor: warn ? 'var(--xx)' : 'var(--border)',
        color: warn ? 'var(--xx)' : 'var(--muted)',
        background: 'color-mix(in srgb, var(--panel) 75%, transparent)',
      }}>{children}</span>
  );
}
