export interface Theme {
  id: string;
  name: string;
  dark: boolean;
  vars: Record<string, string>;
}

const base = (dark: boolean) => (dark
  ? {
      '--shadow': '0 8px 30px rgba(0,0,0,.45)',
      '--hi': '#34d399',
      '--lo': '#475569',
      '--xx': '#f59e0b',
    }
  : {
      '--shadow': '0 8px 24px rgba(15,23,42,.10)',
      '--hi': '#10b981',
      '--lo': '#94a3b8',
      '--xx': '#d97706',
    });

export const THEMES: Theme[] = [
  {
    id: 'blue-dark', name: 'Blue · Dark', dark: true,
    vars: {
      ...base(true),
      '--bg': '#0b1220', '--panel': '#0f1829', '--panel2': '#131f33',
      '--border': '#1e2c46', '--text': '#dbe6f6', '--muted': '#7d90ad',
      '--accent': '#4d9fff', '--accent2': '#1e6fd9', '--grid': '#16233a',
      '--grid2': '#1d2e4b', '--node': '#152238',
    },
  },
  {
    id: 'blue-light', name: 'Blue · Light', dark: false,
    vars: {
      ...base(false),
      '--bg': '#eef3fb', '--panel': '#ffffff', '--panel2': '#f4f8ff',
      '--border': '#d3e0f2', '--text': '#16263d', '--muted': '#60789a',
      '--accent': '#2f7fe0', '--accent2': '#1a63bd', '--grid': '#dde7f5',
      '--grid2': '#cbdaee', '--node': '#ffffff',
    },
  },
  {
    id: 'gray-dark', name: 'Graphite · Dark', dark: true,
    vars: {
      ...base(true),
      '--bg': '#0e0f11', '--panel': '#141618', '--panel2': '#1a1d20',
      '--border': '#26292e', '--text': '#e2e5e9', '--muted': '#8b9199',
      '--accent': '#9aa7b4', '--accent2': '#6e7b89', '--grid': '#1b1e22',
      '--grid2': '#24282d', '--node': '#17191c',
    },
  },
  {
    id: 'gray-light', name: 'Graphite · Light', dark: false,
    vars: {
      ...base(false),
      '--bg': '#f2f3f5', '--panel': '#ffffff', '--panel2': '#f7f8fa',
      '--border': '#dfe2e6', '--text': '#20242a', '--muted': '#6b7280',
      '--accent': '#55606d', '--accent2': '#39424d', '--grid': '#e6e8eb',
      '--grid2': '#d8dbdf', '--node': '#ffffff',
    },
  },
  {
    id: 'pink-dark', name: 'Rose · Dark', dark: true,
    vars: {
      ...base(true),
      '--bg': '#150f16', '--panel': '#1c1420', '--panel2': '#241929',
      '--border': '#3a2740', '--text': '#f0dfee', '--muted': '#ab8fae',
      '--accent': '#e07ab0', '--accent2': '#b85a8e', '--grid': '#251a2a',
      '--grid2': '#33233a', '--node': '#211722',
    },
  },
  {
    id: 'pink-light', name: 'Rose · Light', dark: false,
    vars: {
      ...base(false),
      '--bg': '#fbf1f7', '--panel': '#ffffff', '--panel2': '#fdf5fa',
      '--border': '#f0d9e7', '--text': '#3a2333', '--muted': '#8c6b80',
      '--accent': '#cc5f96', '--accent2': '#a84577', '--grid': '#f4e3ee',
      '--grid2': '#ebd2e2', '--node': '#ffffff',
    },
  },
];

export function applyTheme(t: Theme) {
  const root = document.documentElement;
  Object.entries(t.vars).forEach(([k, v]) => root.style.setProperty(k, v));
  root.style.colorScheme = t.dark ? 'dark' : 'light';
}
