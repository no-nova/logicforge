import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CNode, CustomDef, Doc, NodeType, Wire, portCounts, snap, uid, isGate, GATE_INFO,
} from './circuit';

const LS_KEY = 'logicforge.doc.v1';

export function emptyDoc(): Doc {
  return { nodes: [], wires: [], defs: [] };
}

export function demoDoc(): Doc {
  const a: CNode = { id: 'sw_a', type: 'INPUT', label: 'A', x: 80, y: 180, rot: 0, inputs: 0, value: 1 };
  const b: CNode = { id: 'sw_b', type: 'INPUT', label: 'B', x: 80, y: 300, rot: 0, inputs: 0, value: 0 };
  const n1: CNode = { id: 'g_nand', type: 'NAND', x: 280, y: 200, rot: 0, inputs: 2 };
  const o1: CNode = { id: 'g_or', type: 'OR', x: 280, y: 320, rot: 0, inputs: 2 };
  const g3: CNode = { id: 'g_and', type: 'AND', x: 460, y: 250, rot: 0, inputs: 2 };
  const out: CNode = { id: 'p_out', type: 'OUTPUT', label: 'A ⊕ B', x: 640, y: 262, rot: 0, inputs: 1 };
  const w = (f: string, fp: number, t: string, tp: number): Wire => ({
    id: uid('w'), from: { node: f, port: fp }, to: { node: t, port: tp },
  });
  return {
    nodes: [a, b, n1, o1, g3, out],
    wires: [
      w('sw_a', 0, 'g_nand', 0), w('sw_b', 0, 'g_nand', 1),
      w('sw_a', 0, 'g_or', 0), w('sw_b', 0, 'g_or', 1),
      w('g_nand', 0, 'g_and', 0), w('g_or', 0, 'g_and', 1),
      w('g_and', 0, 'p_out', 0),
    ],
    defs: [],
  };
}

export function defaultInputs(type: NodeType): number {
  if (type === 'OUTPUT') return 1;
  if (isGate(type)) return GATE_INFO[type].minIn;
  return 0;
}

export interface EditorAPI {
  doc: Doc;
  selection: string[];
  selectedWires: string[];
  setSelection: (ids: string[]) => void;
  setSelectedWires: (ids: string[]) => void;
  commit: (updater: (d: Doc) => Doc, label?: string) => void;
  /** live edit without pushing history (e.g. during drag) */
  live: (updater: (d: Doc) => Doc) => void;
  pushHistory: () => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  addNode: (type: NodeType, x: number, y: number, defId?: string) => string;
  deleteSelected: () => void;
  duplicateSelected: () => void;
  rotateSelected: () => void;
  copy: () => void;
  paste: (x?: number, y?: number) => void;
  alignSelected: (mode: 'left' | 'right' | 'top' | 'bottom' | 'hspace' | 'vspace') => void;
  connect: (from: { node: string; port: number }, to: { node: string; port: number }) => void;
  makeCustom: (name: string) => void;
  reset: () => void;
  load: (d: Doc) => void;
  history: string[];
}

export function useEditor(): EditorAPI {
  const [doc, setDoc] = useState<Doc>(() => {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) return JSON.parse(raw) as Doc;
    } catch { /* ignore */ }
    return demoDoc();
  });
  const [past, setPast] = useState<Doc[]>([]);
  const [future, setFuture] = useState<Doc[]>([]);
  const [labels, setLabels] = useState<string[]>([]);
  const [selection, setSelection] = useState<string[]>([]);
  const [selectedWires, setSelectedWires] = useState<string[]>([]);
  const clip = useRef<{ nodes: CNode[]; wires: Wire[] } | null>(null);
  const docRef = useRef(doc);
  docRef.current = doc;

  useEffect(() => {
    const t = setTimeout(() => {
      try { localStorage.setItem(LS_KEY, JSON.stringify(doc)); } catch { /* ignore */ }
    }, 400);
    return () => clearTimeout(t);
  }, [doc]);

  const pushHistory = useCallback(() => {
    setPast((p) => [...p.slice(-60), docRef.current]);
    setFuture([]);
  }, []);

  const commit = useCallback((updater: (d: Doc) => Doc, label = 'edit') => {
    setPast((p) => [...p.slice(-60), docRef.current]);
    setFuture([]);
    setLabels((l) => [...l.slice(-60), label]);
    setDoc((d) => updater(d));
  }, []);

  const live = useCallback((updater: (d: Doc) => Doc) => setDoc((d) => updater(d)), []);

  const undo = useCallback(() => {
    setPast((p) => {
      if (!p.length) return p;
      const prev = p[p.length - 1];
      setFuture((f) => [docRef.current, ...f]);
      setDoc(prev);
      return p.slice(0, -1);
    });
  }, []);

  const redo = useCallback(() => {
    setFuture((f) => {
      if (!f.length) return f;
      setPast((p) => [...p, docRef.current]);
      setDoc(f[0]);
      return f.slice(1);
    });
  }, []);

  const addNode = useCallback((type: NodeType, x: number, y: number, defId?: string) => {
    const id = uid(type.toLowerCase().slice(0, 3) + '_');
    const node: CNode = {
      id, type, x: snap(x), y: snap(y), rot: 0,
      inputs: defaultInputs(type), defId,
      ...(type === 'INPUT' ? { value: 0 as const } : {}),
      ...(type === 'CLOCK' ? { period: 12 } : {}),
    };
    commit((d) => ({ ...d, nodes: [...d.nodes, node] }), `add ${type}`);
    setSelection([id]);
    return id;
  }, [commit]);

  const deleteSelected = useCallback(() => {
    if (!selection.length && !selectedWires.length) return;
    commit((d) => ({
      ...d,
      nodes: d.nodes.filter((n) => !selection.includes(n.id)),
      wires: d.wires.filter(
        (w) => !selectedWires.includes(w.id) &&
          !selection.includes(w.from.node) && !selection.includes(w.to.node)
      ),
    }), 'delete');
    setSelection([]); setSelectedWires([]);
  }, [selection, selectedWires, commit]);

  const cloneChunk = (d: Doc, ids: string[], dx: number, dy: number) => {
    const map = new Map<string, string>();
    const nodes = d.nodes.filter((n) => ids.includes(n.id)).map((n) => {
      const nid = uid('c');
      map.set(n.id, nid);
      return { ...n, id: nid, x: snap(n.x + dx), y: snap(n.y + dy) };
    });
    const wires = d.wires
      .filter((w) => map.has(w.from.node) && map.has(w.to.node))
      .map((w) => ({
        id: uid('w'),
        from: { node: map.get(w.from.node)!, port: w.from.port },
        to: { node: map.get(w.to.node)!, port: w.to.port },
      }));
    return { nodes, wires };
  };

  const duplicateSelected = useCallback(() => {
    if (!selection.length) return;
    const { nodes, wires } = cloneChunk(docRef.current, selection, 40, 40);
    commit((d) => ({ ...d, nodes: [...d.nodes, ...nodes], wires: [...d.wires, ...wires] }), 'duplicate');
    setSelection(nodes.map((n) => n.id));
  }, [selection, commit]);

  const rotateSelected = useCallback(() => {
    if (!selection.length) return;
    commit((d) => ({
      ...d,
      nodes: d.nodes.map((n) => selection.includes(n.id)
        ? { ...n, rot: (((n.rot + 90) % 360) as CNode['rot']) } : n),
    }), 'rotate');
  }, [selection, commit]);

  const copy = useCallback(() => {
    if (!selection.length) return;
    const d = docRef.current;
    clip.current = {
      nodes: d.nodes.filter((n) => selection.includes(n.id)),
      wires: d.wires.filter((w) => selection.includes(w.from.node) && selection.includes(w.to.node)),
    };
  }, [selection]);

  const paste = useCallback((x?: number, y?: number) => {
    const c = clip.current;
    if (!c || !c.nodes.length) return;
    const minX = Math.min(...c.nodes.map((n) => n.x));
    const minY = Math.min(...c.nodes.map((n) => n.y));
    const dx = x != null ? x - minX : 40;
    const dy = y != null ? y - minY : 40;
    const map = new Map<string, string>();
    const nodes = c.nodes.map((n) => {
      const nid = uid('p');
      map.set(n.id, nid);
      return { ...n, id: nid, x: snap(n.x + dx), y: snap(n.y + dy) };
    });
    const wires = c.wires.map((w) => ({
      id: uid('w'),
      from: { node: map.get(w.from.node)!, port: w.from.port },
      to: { node: map.get(w.to.node)!, port: w.to.port },
    }));
    commit((d) => ({ ...d, nodes: [...d.nodes, ...nodes], wires: [...d.wires, ...wires] }), 'paste');
    setSelection(nodes.map((n) => n.id));
  }, [commit]);

  const alignSelected = useCallback((mode: Parameters<EditorAPI['alignSelected']>[0]) => {
    if (selection.length < 2) return;
    commit((d) => {
      const sel = d.nodes.filter((n) => selection.includes(n.id));
      const xs = sel.map((n) => n.x), ys = sel.map((n) => n.y);
      let update: (n: CNode, i: number) => CNode = (n) => n;
      if (mode === 'left') { const v = Math.min(...xs); update = (n) => ({ ...n, x: v }); }
      if (mode === 'right') { const v = Math.max(...xs); update = (n) => ({ ...n, x: v }); }
      if (mode === 'top') { const v = Math.min(...ys); update = (n) => ({ ...n, y: v }); }
      if (mode === 'bottom') { const v = Math.max(...ys); update = (n) => ({ ...n, y: v }); }
      if (mode === 'vspace') {
        const sorted = [...sel].sort((a, b) => a.y - b.y);
        const top = sorted[0].y;
        const order = new Map(sorted.map((n, i) => [n.id, top + i * 100]));
        update = (n) => ({ ...n, y: order.get(n.id) ?? n.y });
      }
      if (mode === 'hspace') {
        const sorted = [...sel].sort((a, b) => a.x - b.x);
        const left = sorted[0].x;
        const order = new Map(sorted.map((n, i) => [n.id, left + i * 160]));
        update = (n) => ({ ...n, x: order.get(n.id) ?? n.x });
      }
      return { ...d, nodes: d.nodes.map((n, i) => (selection.includes(n.id) ? update(n, i) : n)) };
    }, 'align');
  }, [selection, commit]);

  const connect = useCallback((from: { node: string; port: number }, to: { node: string; port: number }) => {
    if (from.node === to.node) return;
    commit((d) => ({
      ...d,
      wires: [
        ...d.wires.filter((w) => !(w.to.node === to.node && w.to.port === to.port)),
        { id: uid('w'), from, to },
      ],
    }), 'connect');
  }, [commit]);

  const makeCustom = useCallback((name: string) => {
    const d = docRef.current;
    const sel = d.nodes.filter((n) => selection.includes(n.id));
    if (sel.length < 2) return;
    const inputs = sel.filter((n) => n.type === 'INPUT').map((n) => n.id);
    const outputs = sel.filter((n) => n.type === 'OUTPUT').map((n) => n.id);
    if (!inputs.length || !outputs.length) return;
    const wires = d.wires.filter((w) => selection.includes(w.from.node) && selection.includes(w.to.node));
    const minX = Math.min(...sel.map((n) => n.x)), minY = Math.min(...sel.map((n) => n.y));
    const def: CustomDef = {
      id: uid('def'), name: name.toUpperCase().slice(0, 12) || 'BLOCK',
      color: '#8b5cf6',
      nodes: sel.map((n) => ({ ...n, x: n.x - minX + 40, y: n.y - minY + 40 })),
      wires: wires.map((w) => ({ ...w })),
      inputs, outputs,
    };
    const inst: CNode = {
      id: uid('cus_'), type: 'CUSTOM', x: snap(minX), y: snap(minY), rot: 0,
      inputs: inputs.length, defId: def.id,
    };
    commit((doc0) => ({
      defs: [...doc0.defs, def],
      nodes: [...doc0.nodes.filter((n) => !selection.includes(n.id)), inst],
      wires: doc0.wires
        .filter((w) => !(selection.includes(w.from.node) || selection.includes(w.to.node))),
    }), 'create component');
    setSelection([inst.id]);
  }, [selection, commit]);

  const reset = useCallback(() => {
    commit(() => emptyDoc(), 'reset');
    setSelection([]); setSelectedWires([]);
  }, [commit]);

  const load = useCallback((d: Doc) => {
    commit(() => d, 'load');
    setSelection([]); setSelectedWires([]);
  }, [commit]);

  return useMemo(() => ({
    doc, selection, selectedWires, setSelection, setSelectedWires,
    commit, live, pushHistory, undo, redo,
    canUndo: past.length > 0, canRedo: future.length > 0,
    addNode, deleteSelected, duplicateSelected, rotateSelected, copy, paste,
    alignSelected, connect, makeCustom, reset, load, history: labels,
  }), [doc, selection, selectedWires, commit, live, pushHistory, undo, redo, past.length,
    future.length, addNode, deleteSelected, duplicateSelected, rotateSelected, copy, paste,
    alignSelected, connect, makeCustom, reset, load, labels]);
}

export function validPortCounts(n: CNode, defs: CustomDef[]) { return portCounts(n, defs); }
