// Core data model + simulation engine for the logic sandbox

export type Val = 0 | 1 | 'X';

export type GateType =
  | 'AND' | 'OR' | 'NOT' | 'NAND' | 'NOR' | 'XOR' | 'XNOR' | 'BUFFER';

export type NodeType = GateType | 'INPUT' | 'OUTPUT' | 'CLOCK' | 'CUSTOM';

export interface CNode {
  id: string;
  type: NodeType;
  label?: string;
  x: number;
  y: number;
  rot: 0 | 90 | 180 | 270;
  inputs: number;      // number of input ports
  defId?: string;      // for CUSTOM
  value?: 0 | 1;       // for INPUT switches (user state)
  period?: number;     // for CLOCK (in ticks)
}

export interface Wire {
  id: string;
  from: { node: string; port: number };  // output port index
  to: { node: string; port: number };    // input port index
}

export interface CustomDef {
  id: string;
  name: string;
  color: string;
  nodes: CNode[];
  wires: Wire[];
  inputs: string[];   // ids of INPUT nodes in order
  outputs: string[];  // ids of OUTPUT nodes in order
}

export interface Circuit {
  nodes: CNode[];
  wires: Wire[];
}

export interface Doc extends Circuit {
  defs: CustomDef[];
}

/* ------------------------------------------------------------------ */
/* Gate metadata                                                       */
/* ------------------------------------------------------------------ */

export const GATE_INFO: Record<
  GateType,
  { expr: (a: string[]) => string; minIn: number; maxIn: number; desc: string }
> = {
  AND:    { expr: (a) => a.join(' · '),                 minIn: 2, maxIn: 8, desc: 'HIGH only when every input is HIGH.' },
  OR:     { expr: (a) => a.join(' + '),                 minIn: 2, maxIn: 8, desc: 'HIGH when at least one input is HIGH.' },
  NOT:    { expr: (a) => `¬${a[0] ?? 'A'}`,             minIn: 1, maxIn: 1, desc: 'Inverts the input signal.' },
  NAND:   { expr: (a) => `¬(${a.join(' · ')})`,         minIn: 2, maxIn: 8, desc: 'Inverted AND. LOW only when all inputs HIGH.' },
  NOR:    { expr: (a) => `¬(${a.join(' + ')})`,         minIn: 2, maxIn: 8, desc: 'Inverted OR. HIGH only when all inputs LOW.' },
  XOR:    { expr: (a) => a.join(' ⊕ '),                 minIn: 2, maxIn: 8, desc: 'HIGH when an odd number of inputs are HIGH.' },
  XNOR:   { expr: (a) => `¬(${a.join(' ⊕ ')})`,         minIn: 2, maxIn: 8, desc: 'HIGH when an even number of inputs are HIGH.' },
  BUFFER: { expr: (a) => `${a[0] ?? 'A'}`,              minIn: 1, maxIn: 1, desc: 'Passes the signal through unchanged.' },
};

export const isGate = (t: NodeType): t is GateType => t in GATE_INFO;

export function portCounts(n: CNode, defs: CustomDef[]): { ins: number; outs: number } {
  if (n.type === 'INPUT' || n.type === 'CLOCK') return { ins: 0, outs: 1 };
  if (n.type === 'OUTPUT') return { ins: 1, outs: 0 };
  if (n.type === 'CUSTOM') {
    const d = defs.find((d) => d.id === n.defId);
    return { ins: d ? d.inputs.length : 0, outs: d ? d.outputs.length : 0 };
  }
  return { ins: n.inputs, outs: 1 };
}

export function nodeTitle(n: CNode, defs: CustomDef[]): string {
  if (n.label) return n.label;
  if (n.type === 'CUSTOM') return defs.find((d) => d.id === n.defId)?.name ?? 'CUSTOM';
  if (n.type === 'INPUT') return 'SWITCH';
  if (n.type === 'OUTPUT') return 'PROBE';
  return n.type;
}

/* ------------------------------------------------------------------ */
/* Boolean evaluation                                                  */
/* ------------------------------------------------------------------ */

export function evalGate(type: GateType, ins: Val[]): Val {
  const hasX = ins.some((v) => v === 'X');
  const ones = ins.filter((v) => v === 1).length;
  switch (type) {
    case 'AND':  return ins.some((v) => v === 0) ? 0 : hasX ? 'X' : 1;
    case 'NAND': return ins.some((v) => v === 0) ? 1 : hasX ? 'X' : 0;
    case 'OR':   return ins.some((v) => v === 1) ? 1 : hasX ? 'X' : 0;
    case 'NOR':  return ins.some((v) => v === 1) ? 0 : hasX ? 'X' : 1;
    case 'XOR':  return hasX ? 'X' : ((ones % 2) as 0 | 1);
    case 'XNOR': return hasX ? 'X' : (((ones + 1) % 2) as 0 | 1);
    case 'NOT':  return ins[0] === 'X' || ins[0] === undefined ? 'X' : ins[0] === 1 ? 0 : 1;
    case 'BUFFER': return ins[0] === undefined ? 'X' : ins[0];
  }
}

/* ------------------------------------------------------------------ */
/* Flattening (hierarchical custom components -> flat netlist)         */
/* ------------------------------------------------------------------ */

interface FlatNode {
  id: string;
  kind: GateType | 'SOURCE';       // SOURCE = switch/clock, driven externally
  ins: (string | null)[];          // flat ids of driving nodes (single output each)
  src?: string;                    // top-level node id for SOURCE
}

export interface FlatNet {
  nodes: Map<string, FlatNode>;
  /** top-level "nodeId:out:i" -> flat node id that carries value */
  outAlias: Map<string, string | null>;
  /** top-level "nodeId:in:i" -> flat node id it resolves to (for reading) */
  inAlias: Map<string, string>;
}

function key(n: string, dir: 'in' | 'out', p: number) { return `${n}:${dir}:${p}`; }

/**
 * Build a flat netlist. Prefix scopes nested instances.
 * Returns maps so the UI can read values for any (top-level) port.
 */
export function flatten(circuit: Circuit, defs: CustomDef[]): FlatNet {
  const nodes = new Map<string, FlatNode>();
  const outAlias = new Map<string, string | null>();
  const inAlias = new Map<string, string>();

  // resolvers inside a scope
  interface Scope {
    prefix: string;
    // maps local "node:in:i" -> flat node id (the sink node) ; "node:out:j" -> flat id (source)
    sinkOf: Map<string, string>;
    sourceOf: Map<string, string>;
    // pending connections: flat sink node id + port index <- source key
    setSrc: (flatId: string, port: number, srcFlatId: string | null) => void;
  }

  const build = (
    c: Circuit,
    prefix: string,
    /** map from local INPUT node id -> flat node id acting as its buffer */
    isTop: boolean
  ): Scope => {
    const sinkOf = new Map<string, string>();
    const sourceOf = new Map<string, string>();
    const setSrc = (flatId: string, port: number, srcFlatId: string | null) => {
      const fn = nodes.get(flatId);
      if (fn && port < fn.ins.length) fn.ins[port] = srcFlatId;
    };

    // create flat nodes
    for (const n of c.nodes) {
      const fid = prefix + n.id;
      if (n.type === 'CUSTOM') {
        const def = defs.find((d) => d.id === n.defId);
        if (!def) continue;
        const inner = build({ nodes: def.nodes, wires: def.wires }, fid + '/', false);
        // custom input port i -> inner INPUT node (acts as buffer)
        def.inputs.forEach((inId, i) => {
          const innerFlat = fid + '/' + inId;
          // ensure it exists as buffer
          if (!nodes.has(innerFlat)) nodes.set(innerFlat, { id: innerFlat, kind: 'BUFFER', ins: [null] });
          sinkOf.set(key(n.id, 'in', i), innerFlat);
        });
        def.outputs.forEach((outId, j) => {
          const innerFlat = fid + '/' + outId;
          if (!nodes.has(innerFlat)) nodes.set(innerFlat, { id: innerFlat, kind: 'BUFFER', ins: [null] });
          sourceOf.set(key(n.id, 'out', j), innerFlat);
        });
        void inner;
      } else if (n.type === 'INPUT' || n.type === 'CLOCK') {
        if (isTop) {
          nodes.set(fid, { id: fid, kind: 'SOURCE', ins: [], src: n.id });
        } else {
          // inside a definition, an INPUT node is a port -> behaves as buffer
          nodes.set(fid, { id: fid, kind: 'BUFFER', ins: [null] });
        }
        sourceOf.set(key(n.id, 'out', 0), fid);
      } else if (n.type === 'OUTPUT') {
        nodes.set(fid, { id: fid, kind: 'BUFFER', ins: [null] });
        sinkOf.set(key(n.id, 'in', 0), fid);
        sourceOf.set(key(n.id, 'out', 0), fid);
      } else {
        nodes.set(fid, { id: fid, kind: n.type as GateType, ins: new Array(n.inputs).fill(null) });
        for (let i = 0; i < n.inputs; i++) sinkOf.set(key(n.id, 'in', i), fid);
        sourceOf.set(key(n.id, 'out', 0), fid);
      }
    }

    // wire them up
    for (const w of c.wires) {
      const src = sourceOf.get(key(w.from.node, 'out', w.from.port));
      const sinkNode = c.nodes.find((n) => n.id === w.to.node);
      if (!src || !sinkNode) continue;
      if (sinkNode.type === 'CUSTOM') {
        const inner = sinkOf.get(key(w.to.node, 'in', w.to.port));
        if (inner) setSrc(inner, 0, src);
      } else {
        const fid = prefix + w.to.node;
        setSrc(fid, sinkNode.type === 'OUTPUT' ? 0 : w.to.port, src);
      }
    }

    if (isTop) {
      for (const [k, v] of sourceOf) outAlias.set(k, v);
      for (const [k, v] of sinkOf) inAlias.set(k, v);
    }
    return { prefix, sinkOf, sourceOf, setSrc };
  };

  build(circuit, '', true);
  return { nodes, outAlias, inAlias };
}

/* ------------------------------------------------------------------ */
/* Simulation                                                          */
/* ------------------------------------------------------------------ */

export interface SimResult {
  /** flat node id -> value */
  values: Map<string, Val>;
  /** wire id -> value */
  wireValues: Map<string, Val>;
  /** top-level node id -> output value */
  nodeOut: Map<string, Val>;
  /** top-level "node:in:i" -> value */
  nodeIn: Map<string, Val>;
  stable: boolean;
  iterations: number;
  floating: string[]; // "nodeId:in:i" list
}

export function simulate(
  circuit: Circuit,
  defs: CustomDef[],
  sourceValues: Map<string, Val>
): SimResult {
  const net = flatten(circuit, defs);
  const values = new Map<string, Val>();
  for (const id of net.nodes.keys()) values.set(id, 'X');

  let stable = false;
  let iterations = 0;
  const MAX = 80;
  while (iterations < MAX) {
    iterations++;
    let changed = false;
    for (const fn of net.nodes.values()) {
      let v: Val;
      if (fn.kind === 'SOURCE') {
        v = sourceValues.get(fn.src!) ?? 0;
      } else {
        const ins: Val[] = fn.ins.map((s) => (s == null ? 'X' : values.get(s) ?? 'X'));
        v = evalGate(fn.kind, ins.length ? ins : ['X']);
      }
      if (values.get(fn.id) !== v) { values.set(fn.id, v); changed = true; }
    }
    if (!changed) { stable = true; break; }
  }

  const nodeOut = new Map<string, Val>();
  for (const [k, flat] of net.outAlias) {
    const nodeId = k.split(':')[0];
    nodeOut.set(nodeId, flat ? values.get(flat) ?? 'X' : 'X');
  }
  // multi-output customs: store per port too
  const portOut = new Map<string, Val>();
  for (const [k, flat] of net.outAlias) portOut.set(k, flat ? values.get(flat) ?? 'X' : 'X');

  const wireValues = new Map<string, Val>();
  for (const w of circuit.wires) {
    wireValues.set(w.id, portOut.get(key(w.from.node, 'out', w.from.port)) ?? 'X');
  }

  const nodeIn = new Map<string, Val>();
  const floating: string[] = [];
  for (const n of circuit.nodes) {
    const { ins } = portCounts(n, defs);
    for (let i = 0; i < ins; i++) {
      const w = circuit.wires.find((w) => w.to.node === n.id && w.to.port === i);
      const v: Val = w ? wireValues.get(w.id) ?? 'X' : 'X';
      nodeIn.set(key(n.id, 'in', i), v);
      if (!w) floating.push(key(n.id, 'in', i));
    }
  }
  for (const [k, v] of portOut) nodeOut.set(k, v);

  return { values, wireValues, nodeOut, nodeIn, stable, iterations, floating };
}

export const outKey = (node: string, port: number) => key(node, 'out', port);
export const inKey = (node: string, port: number) => key(node, 'in', port);

/* ------------------------------------------------------------------ */
/* Truth tables                                                        */
/* ------------------------------------------------------------------ */

export function gateTruthTable(type: GateType, nIn: number) {
  const rows: { ins: (0 | 1)[]; out: Val }[] = [];
  const n = Math.min(nIn, 4);
  for (let m = 0; m < 1 << n; m++) {
    const ins: (0 | 1)[] = [];
    for (let i = n - 1; i >= 0; i--) ins.push(((m >> i) & 1) as 0 | 1);
    rows.push({ ins, out: evalGate(type, ins) });
  }
  return rows;
}

export function circuitTruthTable(circuit: Circuit, defs: CustomDef[]) {
  const switches = circuit.nodes.filter((n) => n.type === 'INPUT');
  const probes = circuit.nodes.filter((n) => n.type === 'OUTPUT');
  if (!switches.length || !probes.length || switches.length > 8) return null;
  const rows: { ins: (0 | 1)[]; outs: Val[] }[] = [];
  const n = switches.length;
  for (let m = 0; m < 1 << n; m++) {
    const sv = new Map<string, Val>();
    const ins: (0 | 1)[] = [];
    switches.forEach((s, i) => {
      const bit = ((m >> (n - 1 - i)) & 1) as 0 | 1;
      ins.push(bit);
      sv.set(s.id, bit);
    });
    circuit.nodes.filter((x) => x.type === 'CLOCK').forEach((c) => sv.set(c.id, 0));
    const r = simulate(circuit, defs, sv);
    rows.push({ ins, outs: probes.map((p) => r.nodeIn.get(inKey(p.id, 0)) ?? 'X') });
  }
  return { switches, probes, rows };
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

let idc = 0;
export const uid = (p = 'n') => `${p}${Date.now().toString(36).slice(-4)}${(idc++).toString(36)}`;

export const GRID = 20;
export const snap = (v: number) => Math.round(v / GRID) * GRID;

export function nodeSize(n: CNode, defs: CustomDef[]) {
  const { ins, outs } = portCounts(n, defs);
  if (n.type === 'INPUT' || n.type === 'OUTPUT' || n.type === 'CLOCK') return { w: 76, h: 48 };
  const rows = Math.max(ins, outs, 1);
  const w = n.type === 'CUSTOM' ? 110 : 92;
  return { w, h: Math.max(56, 24 + rows * 22) };
}

/** local (unrotated) port position relative to node top-left */
export function localPort(n: CNode, defs: CustomDef[], dir: 'in' | 'out', i: number) {
  const { w, h } = nodeSize(n, defs);
  const { ins, outs } = portCounts(n, defs);
  const count = dir === 'in' ? ins : outs;
  const y = count <= 1 ? h / 2 : 22 + ((h - 30) * i) / (count - 1);
  return { x: dir === 'in' ? 0 : w, y };
}

export function portPos(n: CNode, defs: CustomDef[], dir: 'in' | 'out', i: number) {
  const { w, h } = nodeSize(n, defs);
  const p = localPort(n, defs, dir, i);
  const cx = w / 2, cy = h / 2;
  const a = (n.rot * Math.PI) / 180;
  const dx = p.x - cx, dy = p.y - cy;
  const rx = dx * Math.cos(a) - dy * Math.sin(a);
  const ry = dx * Math.sin(a) + dy * Math.cos(a);
  return { x: n.x + cx + rx, y: n.y + cy + ry };
}

/** outward direction unit vector for a port, after rotation */
export function portDir(n: CNode, dir: 'in' | 'out') {
  const base = dir === 'in' ? -1 : 1;
  const a = (n.rot * Math.PI) / 180;
  return { x: base * Math.cos(a), y: base * Math.sin(a) };
}
