import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  CNode, CustomDef, GRID, SimResult, Val, inKey, nodeSize, nodeTitle,
  outKey, portCounts, portDir, portPos, snap, localPort,
} from '../lib/circuit';
import { EditorAPI } from '../lib/store';

export interface View { x: number; y: number; z: number }

interface Props {
  ed: EditorAPI;
  sim: SimResult;
  view: View;
  setView: React.Dispatch<React.SetStateAction<View>>;
  running: boolean;
  wireStyle: 'curve' | 'ortho';
  snapOn: boolean;
  onToggleSwitch: (id: string) => void;
  probeIds: string[];
}

type Drag =
  | { kind: 'pan'; sx: number; sy: number; ox: number; oy: number }
  | { kind: 'node'; sx: number; sy: number; start: Map<string, { x: number; y: number }> }
  | { kind: 'wire'; from: { node: string; port: number } | null; to: { node: string; port: number } | null; x: number; y: number }
  | { kind: 'marquee'; sx: number; sy: number; x: number; y: number }
  | null;

const valColor = (v: Val) => (v === 1 ? 'var(--hi)' : v === 0 ? 'var(--lo)' : 'var(--xx)');

export default function Canvas(props: Props) {
  const { ed, sim, view, setView, running, wireStyle, snapOn, onToggleSwitch } = props;
  const { doc, selection, selectedWires } = ed;
  const defs = doc.defs;
  const ref = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<Drag>(null);
  const [guides, setGuides] = useState<{ v: number[]; h: number[] }>({ v: [], h: [] });
  const [hoverPort, setHoverPort] = useState<string | null>(null);

  const toWorld = useCallback((cx: number, cy: number) => {
    const r = ref.current!.getBoundingClientRect();
    return { x: (cx - r.left - view.x) / view.z, y: (cy - r.top - view.y) / view.z };
  }, [view]);

  /* ----------------------------- zoom ----------------------------- */
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      if (e.ctrlKey || e.metaKey || !e.shiftKey) {
        setView((v) => {
          const z = Math.min(2.6, Math.max(0.2, v.z * Math.exp(-e.deltaY * 0.0016)));
          const k = z / v.z;
          return { z, x: mx - (mx - v.x) * k, y: my - (my - v.y) * k };
        });
      } else {
        setView((v) => ({ ...v, x: v.x - e.deltaX, y: v.y - e.deltaY }));
      }
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, [setView]);

  /* --------------------------- drag & drop ------------------------- */
  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const raw = e.dataTransfer.getData('application/x-node');
    if (!raw) return;
    const { type, defId } = JSON.parse(raw);
    const p = toWorld(e.clientX, e.clientY);
    ed.addNode(type, p.x - 45, p.y - 25, defId);
  };

  /* ---------------------------- pointer ---------------------------- */
  const startNodeDrag = (e: React.PointerEvent, id: string) => {
    e.stopPropagation();
    const add = e.shiftKey || e.metaKey || e.ctrlKey;
    let sel = selection;
    if (add) sel = selection.includes(id) ? selection.filter((s) => s !== id) : [...selection, id];
    else if (!selection.includes(id)) sel = [id];
    ed.setSelection(sel);
    ed.setSelectedWires([]);
    const p = toWorld(e.clientX, e.clientY);
    const start = new Map(doc.nodes.filter((n) => sel.includes(n.id)).map((n) => [n.id, { x: n.x, y: n.y }]));
    ed.pushHistory();
    setDrag({ kind: 'node', sx: p.x, sy: p.y, start });
  };

  const startPortDrag = (e: React.PointerEvent, node: string, dir: 'in' | 'out', port: number) => {
    e.stopPropagation();
    const p = toWorld(e.clientX, e.clientY);
    if (dir === 'out') setDrag({ kind: 'wire', from: { node, port }, to: null, x: p.x, y: p.y });
    else {
      // dragging from an input: detach existing wire if any
      const existing = doc.wires.find((w) => w.to.node === node && w.to.port === port);
      if (existing) {
        ed.commit((d) => ({ ...d, wires: d.wires.filter((w) => w.id !== existing.id) }), 'detach');
        setDrag({ kind: 'wire', from: existing.from, to: null, x: p.x, y: p.y });
      } else setDrag({ kind: 'wire', from: null, to: { node, port }, x: p.x, y: p.y });
    }
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if (e.button === 1 || e.button === 2 || e.altKey || e.buttons === 4) {
      setDrag({ kind: 'pan', sx: e.clientX, sy: e.clientY, ox: view.x, oy: view.y });
      return;
    }
    if (e.button !== 0) return;
    const p = toWorld(e.clientX, e.clientY);
    if (!e.shiftKey) { ed.setSelection([]); ed.setSelectedWires([]); }
    setDrag({ kind: 'marquee', sx: p.x, sy: p.y, x: p.x, y: p.y });
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag) return;
    if (drag.kind === 'pan') {
      setView({ x: drag.ox + (e.clientX - drag.sx), y: drag.oy + (e.clientY - drag.sy), z: view.z });
      return;
    }
    const p = toWorld(e.clientX, e.clientY);
    if (drag.kind === 'node') {
      const dx = p.x - drag.sx, dy = p.y - drag.sy;
      const gv: number[] = [], gh: number[] = [];
      ed.live((d) => ({
        ...d,
        nodes: d.nodes.map((n) => {
          const s = drag.start.get(n.id);
          if (!s) return n;
          let nx = s.x + dx, ny = s.y + dy;
          if (snapOn) { nx = snap(nx); ny = snap(ny); }
          for (const o of d.nodes) {
            if (drag.start.has(o.id)) continue;
            if (Math.abs(o.x - nx) < 8) { nx = o.x; gv.push(o.x); }
            if (Math.abs(o.y - ny) < 8) { ny = o.y; gh.push(o.y); }
          }
          return { ...n, x: nx, y: ny };
        }),
      }));
      setGuides({ v: gv, h: gh });
    } else if (drag.kind === 'wire' || drag.kind === 'marquee') {
      setDrag({ ...drag, x: p.x, y: p.y });
    }
  };

  const onPointerUp = (e: React.PointerEvent) => {
    if (drag?.kind === 'marquee') {
      const x1 = Math.min(drag.sx, drag.x), x2 = Math.max(drag.sx, drag.x);
      const y1 = Math.min(drag.sy, drag.y), y2 = Math.max(drag.sy, drag.y);
      if (Math.abs(x2 - x1) > 4 || Math.abs(y2 - y1) > 4) {
        const hit = doc.nodes.filter((n) => {
          const { w, h } = nodeSize(n, defs);
          return n.x < x2 && n.x + w > x1 && n.y < y2 && n.y + h > y1;
        }).map((n) => n.id);
        ed.setSelection(e.shiftKey ? [...new Set([...selection, ...hit])] : hit);
      }
    }
    if (drag?.kind === 'wire' && hoverPort) {
      const [nid, dir, pi] = hoverPort.split('|');
      if (drag.from && dir === 'in') ed.connect(drag.from, { node: nid, port: +pi });
      else if (drag.to && dir === 'out') ed.connect({ node: nid, port: +pi }, drag.to);
    }
    setGuides({ v: [], h: [] });
    setDrag(null);
  };

  /* ---------------------------- geometry --------------------------- */
  const wirePath = (a: { x: number; y: number }, b: { x: number; y: number },
                    da: { x: number; y: number }, db: { x: number; y: number }) => {
    const dist = Math.hypot(b.x - a.x, b.y - a.y);
    const k = Math.min(170, Math.max(36, dist * 0.45));
    if (wireStyle === 'ortho') {
      const m = a.x + (b.x - a.x) / 2;
      const back = b.x < a.x + 40;
      if (!back) return `M${a.x},${a.y} L${m},${a.y} L${m},${b.y} L${b.x},${b.y}`;
      const off = 46;
      const my = (a.y + b.y) / 2 + (Math.abs(b.y - a.y) < 20 ? 70 : 0);
      return `M${a.x},${a.y} L${a.x + off},${a.y} L${a.x + off},${my} L${b.x - off},${my} L${b.x - off},${b.y} L${b.x},${b.y}`;
    }
    const c1 = { x: a.x + da.x * k, y: a.y + da.y * k };
    const c2 = { x: b.x + db.x * k, y: b.y + db.y * k };
    return `M${a.x},${a.y} C${c1.x},${c1.y} ${c2.x},${c2.y} ${b.x},${b.y}`;
  };

  const nodeMap = new Map(doc.nodes.map((n) => [n.id, n]));

  const wireGeo = doc.wires.map((w) => {
    const a = nodeMap.get(w.from.node), b = nodeMap.get(w.to.node);
    if (!a || !b) return null;
    if (w.from.port >= portCounts(a, defs).outs || w.to.port >= portCounts(b, defs).ins) return null;
    const pa = portPos(a, defs, 'out', w.from.port);
    const pb = portPos(b, defs, 'in', w.to.port);
    const d = wirePath(pa, pb, portDir(a, 'out'), portDir(b, 'in'));
    return { w, d, v: sim.wireValues.get(w.id) ?? 'X', pa, pb };
  }).filter(Boolean) as { w: any; d: string; v: Val; pa: any; pb: any }[];

  /* ----------------------------- render ---------------------------- */
  const gridSize = GRID * view.z;
  return (
    <div
      ref={ref}
      className="relative h-full w-full overflow-hidden select-none"
      style={{
        background: 'var(--bg)',
        backgroundImage:
          `linear-gradient(to right, var(--grid) 1px, transparent 1px),
           linear-gradient(to bottom, var(--grid) 1px, transparent 1px),
           linear-gradient(to right, var(--grid2) 1px, transparent 1px),
           linear-gradient(to bottom, var(--grid2) 1px, transparent 1px)`,
        backgroundSize:
          `${gridSize}px ${gridSize}px, ${gridSize}px ${gridSize}px, ${gridSize * 5}px ${gridSize * 5}px, ${gridSize * 5}px ${gridSize * 5}px`,
        backgroundPosition: `${view.x}px ${view.y}px`,
        cursor: drag?.kind === 'pan' ? 'grabbing' : 'default',
      }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      onContextMenu={(e) => e.preventDefault()}
      onDragOver={(e) => e.preventDefault()}
      onDrop={onDrop}
    >
      <svg className="absolute inset-0 h-full w-full" style={{ touchAction: 'none' }}>
        <defs>
          <filter id="glow" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="3" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        <g transform={`translate(${view.x},${view.y}) scale(${view.z})`}>
          {/* alignment guides */}
          {guides.v.map((x, i) => (
            <line key={'gv' + i} x1={x} y1={-9000} x2={x} y2={9000} stroke="var(--accent)" strokeWidth={1 / view.z} strokeDasharray="6 6" opacity={0.7} />
          ))}
          {guides.h.map((y, i) => (
            <line key={'gh' + i} x1={-9000} y1={y} x2={9000} y2={y} stroke="var(--accent)" strokeWidth={1 / view.z} strokeDasharray="6 6" opacity={0.7} />
          ))}

          {/* wires */}
          <g>
            {wireGeo.map(({ w, d, v }) => {
              const sel = selectedWires.includes(w.id);
              const col = valColor(v);
              return (
                <g key={w.id}>
                  <path d={d} fill="none" stroke="transparent" strokeWidth={14}
                    style={{ cursor: 'pointer' }}
                    onPointerDown={(e) => { e.stopPropagation(); ed.setSelectedWires([w.id]); ed.setSelection([]); }}
                  />
                  <path d={d} fill="none" stroke={col} strokeWidth={sel ? 3.6 : 2.2}
                    strokeLinecap="round" opacity={v === 'X' ? 0.55 : 0.95}
                    strokeDasharray={v === 'X' ? '5 5' : undefined}
                    filter={v === 1 ? 'url(#glow)' : undefined} />
                  {sel && <path d={d} fill="none" stroke="var(--accent)" strokeWidth={7} opacity={0.25} strokeLinecap="round" />}
                  {running && v === 1 && (
                    <circle r={3.2} fill="#ffffff" opacity={0.9}>
                      <animateMotion dur="1.1s" repeatCount="indefinite" path={d} />
                    </circle>
                  )}
                </g>
              );
            })}
            {drag?.kind === 'wire' && (() => {
              const anchorId = drag.from?.node ?? drag.to!.node;
              const an = nodeMap.get(anchorId);
              if (!an) return null;
              const dir = drag.from ? 'out' : 'in';
              const pa = portPos(an, defs, dir as any, (drag.from ?? drag.to)!.port);
              const d = drag.from
                ? wirePath(pa, { x: drag.x, y: drag.y }, portDir(an, 'out'), { x: -1, y: 0 })
                : wirePath({ x: drag.x, y: drag.y }, pa, { x: 1, y: 0 }, portDir(an, 'in'));
              return <path d={d} fill="none" stroke="var(--accent)" strokeWidth={2.4} strokeDasharray="6 4" />;
            })()}
          </g>

          {/* nodes */}
          {doc.nodes.map((n) => (
            <NodeView
              key={n.id} n={n} defs={defs} sim={sim}
              selected={selection.includes(n.id)}
              onBodyDown={(e) => startNodeDrag(e, n.id)}
              onPortDown={startPortDrag}
              onHoverPort={setHoverPort}
              hoverPort={hoverPort}
              onToggle={() => onToggleSwitch(n.id)}
              wiring={drag?.kind === 'wire'}
            />
          ))}
        </g>
      </svg>

      {drag?.kind === 'marquee' && (
        <div className="pointer-events-none absolute border border-[var(--accent)] bg-[var(--accent)]/10"
          style={{
            left: Math.min(drag.sx, drag.x) * view.z + view.x,
            top: Math.min(drag.sy, drag.y) * view.z + view.y,
            width: Math.abs(drag.x - drag.sx) * view.z,
            height: Math.abs(drag.y - drag.sy) * view.z,
          }} />
      )}

      {!doc.nodes.length && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="text-center text-[var(--muted)]">
            <div className="text-sm tracking-[0.3em] uppercase">empty workspace</div>
            <div className="mt-2 text-xs">Drag components from the library · scroll to zoom · alt-drag to pan</div>
          </div>
        </div>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------- */

function NodeView({
  n, defs, sim, selected, onBodyDown, onPortDown, onHoverPort, hoverPort, onToggle, wiring,
}: {
  n: CNode; defs: CustomDef[]; sim: SimResult; selected: boolean;
  onBodyDown: (e: React.PointerEvent) => void;
  onPortDown: (e: React.PointerEvent, node: string, dir: 'in' | 'out', port: number) => void;
  onHoverPort: (k: string | null) => void;
  hoverPort: string | null;
  onToggle: () => void;
  wiring: boolean;
}) {
  const { w, h } = nodeSize(n, defs);
  const { ins, outs } = portCounts(n, defs);
  const out = sim.nodeOut.get(n.type === 'OUTPUT' ? n.id : outKey(n.id, 0)) ?? sim.nodeOut.get(n.id) ?? 'X';
  const title = nodeTitle(n, defs);
  const isSwitch = n.type === 'INPUT' || n.type === 'CLOCK';
  const isProbe = n.type === 'OUTPUT';
  const probeVal = isProbe ? sim.nodeIn.get(inKey(n.id, 0)) ?? 'X' : out;
  const state: Val = isProbe ? probeVal : out;
  const col = valColor(state);
  const floating = Array.from({ length: ins }).some((_, i) => sim.floating.includes(inKey(n.id, i)));

  const body = (
    <g>
      <rect x={0} y={0} width={w} height={h} rx={10}
        fill="var(--node)" stroke={selected ? 'var(--accent)' : 'var(--border)'}
        strokeWidth={selected ? 2 : 1.2} />
      {selected && <rect x={-3} y={-3} width={w + 6} height={h + 6} rx={13} fill="none" stroke="var(--accent)" opacity={0.3} strokeWidth={2} />}
      {n.type === 'CUSTOM' && <rect x={0} y={0} width={w} height={4} rx={2} fill="var(--accent)" opacity={0.8} />}
      {floating && !isSwitch && (
        <rect x={0} y={0} width={w} height={h} rx={10} fill="none" stroke="var(--xx)" strokeWidth={1.4} strokeDasharray="4 4" opacity={0.85} />
      )}
      <text x={w / 2} y={isSwitch || isProbe ? 18 : h / 2 + 1} textAnchor="middle"
        dominantBaseline={isSwitch || isProbe ? 'auto' : 'middle'}
        fontSize={n.type === 'CUSTOM' ? 12 : 13} fontWeight={700}
        fill="var(--text)" style={{ letterSpacing: '0.06em', pointerEvents: 'none' }}>
        {title}
      </text>
      {!isSwitch && !isProbe && (
        <>
          <circle cx={w - 12} cy={11} r={4} fill={col} filter={state === 1 ? 'url(#glow)' : undefined} />
          <text x={10} y={h - 7} fontSize={8} fill="var(--muted)" style={{ pointerEvents: 'none' }}>
            {n.type === 'CUSTOM' ? 'BLOCK' : `${ins}-IN`}
          </text>
        </>
      )}
      {isSwitch && (
        <g onPointerDown={(e) => { e.stopPropagation(); onToggle(); }} style={{ cursor: 'pointer' }}>
          <rect x={14} y={24} width={48} height={18} rx={9} fill={state === 1 ? 'var(--hi)' : 'var(--lo)'} opacity={0.85} />
          <circle cx={state === 1 ? 53 : 23} cy={33} r={7} fill="#fff" />
          {n.type === 'CLOCK' && <text x={w / 2} y={h + 12} textAnchor="middle" fontSize={8} fill="var(--muted)">CLK</text>}
        </g>
      )}
      {isProbe && (
        <g>
          <circle cx={w / 2} cy={33} r={10} fill={col} opacity={state === 'X' ? 0.4 : 1}
            filter={state === 1 ? 'url(#glow)' : undefined} />
          <text x={w / 2} y={37} textAnchor="middle" fontSize={10} fontWeight={700} fill="var(--node)">
            {state === 'X' ? '?' : state}
          </text>
        </g>
      )}
    </g>
  );

  const ports: React.ReactNode[] = [];
  for (let i = 0; i < ins; i++) {
    const p = localPort(n, defs, 'in', i);
    const v = sim.nodeIn.get(inKey(n.id, i)) ?? 'X';
    const k = `${n.id}|in|${i}`;
    ports.push(
      <g key={k} onPointerDown={(e) => onPortDown(e, n.id, 'in', i)}
        onPointerEnter={() => onHoverPort(k)} onPointerLeave={() => onHoverPort(null)}
        style={{ cursor: 'crosshair' }}>
        <circle cx={p.x} cy={p.y} r={9} fill="transparent" />
        <circle cx={p.x} cy={p.y} r={hoverPort === k && wiring ? 6.5 : 4.5}
          fill={valColor(v)} stroke="var(--panel)" strokeWidth={1.5} />
      </g>
    );
  }
  for (let i = 0; i < outs; i++) {
    const p = localPort(n, defs, 'out', i);
    const v = sim.nodeOut.get(outKey(n.id, i)) ?? 'X';
    const k = `${n.id}|out|${i}`;
    ports.push(
      <g key={k} onPointerDown={(e) => onPortDown(e, n.id, 'out', i)}
        onPointerEnter={() => onHoverPort(k)} onPointerLeave={() => onHoverPort(null)}
        style={{ cursor: 'crosshair' }}>
        <circle cx={p.x} cy={p.y} r={9} fill="transparent" />
        <circle cx={p.x} cy={p.y} r={hoverPort === k && wiring ? 6.5 : 4.5}
          fill={valColor(v)} stroke="var(--panel)" strokeWidth={1.5} />
      </g>
    );
  }

  return (
    <g transform={`translate(${n.x},${n.y}) rotate(${n.rot},${w / 2},${h / 2})`}>
      <g onPointerDown={onBodyDown} style={{ cursor: 'move' }}>{body}</g>
      {ports}
    </g>
  );
}
