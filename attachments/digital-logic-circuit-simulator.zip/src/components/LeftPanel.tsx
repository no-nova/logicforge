import { GATE_INFO, GateType, NodeType } from '../lib/circuit';
import { EditorAPI } from '../lib/store';

const GATES: GateType[] = ['AND', 'OR', 'NOT', 'NAND', 'NOR', 'XOR', 'XNOR', 'BUFFER'];
const IO: { type: NodeType; name: string; hint: string }[] = [
  { type: 'INPUT', name: 'Switch', hint: 'Toggleable HIGH / LOW source' },
  { type: 'CLOCK', name: 'Clock', hint: 'Oscillates while simulation runs' },
  { type: 'OUTPUT', name: 'Probe', hint: 'Indicator / circuit output' },
];

function Tile({
  label, hint, payload, onAdd, accent,
}: { label: string; hint: string; payload: string; onAdd: () => void; accent?: boolean }) {
  return (
    <button
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData('application/x-node', payload);
        e.dataTransfer.effectAllowed = 'copy';
      }}
      onClick={onAdd}
      title={hint}
      className="group flex w-full items-center gap-2.5 rounded-lg border border-[var(--border)] bg-[var(--panel2)] px-2.5 py-2 text-left transition
                 hover:border-[var(--accent)] hover:bg-[var(--panel)] active:scale-[0.98]"
    >
      <span
        className="grid h-7 w-7 shrink-0 place-items-center rounded-md text-[9px] font-bold tracking-tight"
        style={{
          background: accent ? 'var(--accent)' : 'color-mix(in srgb, var(--accent) 16%, transparent)',
          color: accent ? 'var(--panel)' : 'var(--accent)',
        }}
      >
        {label.slice(0, 4)}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[12px] font-semibold text-[var(--text)]">{label}</span>
        <span className="block truncate text-[10px] text-[var(--muted)]">{hint}</span>
      </span>
    </button>
  );
}

export default function LeftPanel({ ed, centerWorld }: { ed: EditorAPI; centerWorld: () => { x: number; y: number } }) {
  const add = (type: NodeType, defId?: string) => {
    const c = centerWorld();
    ed.addNode(type, c.x + (Math.random() * 60 - 30), c.y + (Math.random() * 60 - 30), defId);
  };

  return (
    <div className="flex h-full flex-col gap-4 overflow-y-auto p-3">
      <Section title="Logic Gates" count={GATES.length}>
        <div className="grid grid-cols-1 gap-1.5">
          {GATES.map((g) => (
            <Tile key={g} label={g} hint={GATE_INFO[g].desc} payload={JSON.stringify({ type: g })} onAdd={() => add(g)} />
          ))}
        </div>
      </Section>

      <Section title="I / O" count={IO.length}>
        <div className="grid grid-cols-1 gap-1.5">
          {IO.map((i) => (
            <Tile key={i.type} label={i.name} hint={i.hint} payload={JSON.stringify({ type: i.type })} onAdd={() => add(i.type)} accent />
          ))}
        </div>
      </Section>

      <Section title="Custom Components" count={ed.doc.defs.length}>
        {!ed.doc.defs.length && (
          <p className="rounded-lg border border-dashed border-[var(--border)] px-2.5 py-3 text-[10px] leading-relaxed text-[var(--muted)]">
            Select a sub-circuit containing at least one switch and one probe, then use
            <span className="text-[var(--accent)]"> Pack ⌘G </span> in the inspector to build a reusable block.
          </p>
        )}
        <div className="grid grid-cols-1 gap-1.5">
          {ed.doc.defs.map((d) => (
            <div key={d.id} className="flex items-center gap-1">
              <div className="min-w-0 flex-1">
                <Tile
                  label={d.name}
                  hint={`${d.inputs.length} in · ${d.outputs.length} out · ${d.nodes.length} nodes`}
                  payload={JSON.stringify({ type: 'CUSTOM', defId: d.id })}
                  onAdd={() => add('CUSTOM', d.id)}
                />
              </div>
              <button
                onClick={() => ed.commit((doc) => ({
                  ...doc,
                  defs: doc.defs.filter((x) => x.id !== d.id),
                  nodes: doc.nodes.filter((n) => n.defId !== d.id),
                }), 'remove component')}
                className="grid h-7 w-7 shrink-0 place-items-center rounded-md border border-[var(--border)] text-[var(--muted)] hover:border-[var(--xx)] hover:text-[var(--xx)]"
                title="Delete component"
              >✕</button>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

function Section({ title, count, children }: { title: string; count: number; children: React.ReactNode }) {
  return (
    <section className="space-y-2">
      <header className="flex items-center justify-between px-0.5">
        <h3 className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--muted)]">{title}</h3>
        <span className="rounded px-1.5 py-0.5 text-[9px] font-semibold text-[var(--muted)] ring-1 ring-[var(--border)]">{count}</span>
      </header>
      {children}
    </section>
  );
}
