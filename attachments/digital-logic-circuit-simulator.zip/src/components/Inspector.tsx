import { useMemo, useState } from 'react';
import {
  CNode, GATE_INFO, GateType, SimResult, Val, circuitTruthTable, gateTruthTable,
  inKey, isGate, nodeTitle, outKey, portCounts,
} from '../lib/circuit';
import { EditorAPI } from '../lib/store';

const chip = (v: Val) =>
  v === 1 ? 'text-[var(--hi)] ring-[var(--hi)]/40 bg-[var(--hi)]/10'
    : v === 0 ? 'text-[var(--muted)] ring-[var(--border)] bg-[var(--panel2)]'
      : 'text-[var(--xx)] ring-[var(--xx)]/40 bg-[var(--xx)]/10';

function Val_({ v }: { v: Val }) {
  return <span className={`inline-grid h-5 min-w-5 place-items-center rounded px-1 text-[10px] font-bold ring-1 ${chip(v)}`}>{v === 'X' ? 'Z' : v}</span>;
}

export default function Inspector({ ed, sim }: { ed: EditorAPI; sim: SimResult }) {
  const [tab, setTab] = useState<'props' | 'truth' | 'debug'>('props');
  const [packName, setPackName] = useState('');
  const { doc, selection } = ed;
  const node = selection.length === 1 ? doc.nodes.find((n) => n.id === selection[0]) ?? null : null;

  const update = (patch: Partial<CNode>) =>
    node && ed.commit((d) => ({ ...d, nodes: d.nodes.map((n) => (n.id === node.id ? { ...n, ...patch } : n)) }), 'property');

  const ctt = useMemo(() => (tab === 'truth' && !node ? circuitTruthTable(doc, doc.defs) : null), [tab, node, doc]);

  return (
    <div className="flex h-full flex-col">
      <div className="flex gap-1 border-b border-[var(--border)] p-2">
        {(['props', 'truth', 'debug'] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 rounded-md px-2 py-1.5 text-[10px] font-bold uppercase tracking-[0.12em] transition ${
              tab === t ? 'bg-[var(--accent)] text-[var(--panel)]' : 'text-[var(--muted)] hover:bg-[var(--panel2)]'}`}>
            {t === 'props' ? 'Inspector' : t === 'truth' ? 'Truth' : 'Debug'}
          </button>
        ))}
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto p-3">
        {tab === 'props' && (
          <>
            {!node && (
              <>
                <Empty text={selection.length > 1 ? `${selection.length} nodes selected` : 'No selection'} />
                {selection.length > 1 && (
                  <Card title="Pack into component">
                    <div className="flex gap-1.5">
                      <input value={packName} onChange={(e) => setPackName(e.target.value)} placeholder="NAME"
                        className="min-w-0 flex-1 rounded-md border border-[var(--border)] bg-[var(--panel2)] px-2 py-1.5 text-[11px] text-[var(--text)] outline-none focus:border-[var(--accent)]" />
                      <button onClick={() => { ed.makeCustom(packName || 'BLOCK'); setPackName(''); }}
                        className="rounded-md bg-[var(--accent)] px-3 py-1.5 text-[11px] font-bold text-[var(--panel)]">Pack</button>
                    </div>
                    <p className="mt-2 text-[10px] leading-relaxed text-[var(--muted)]">
                      Selection must contain switches (become inputs) and probes (become outputs).
                    </p>
                  </Card>
                )}
                <Card title="Circuit summary">
                  <Row k="Nodes" v={String(doc.nodes.length)} />
                  <Row k="Wires" v={String(doc.wires.length)} />
                  <Row k="Components" v={String(doc.defs.length)} />
                  <Row k="Floating inputs" v={String(sim.floating.length)} />
                  <Row k="Converged" v={sim.stable ? `yes (${sim.iterations} it)` : 'oscillating'} />
                </Card>
              </>
            )}

            {node && (
              <>
                <Card title="Identity">
                  <Row k="Type" v={node.type} />
                  <Row k="ID" v={node.id} mono />
                  <label className="mt-2 block text-[10px] uppercase tracking-wider text-[var(--muted)]">Label</label>
                  <input value={node.label ?? ''} onChange={(e) => update({ label: e.target.value })}
                    placeholder={nodeTitle(node, doc.defs)}
                    className="mt-1 w-full rounded-md border border-[var(--border)] bg-[var(--panel2)] px-2 py-1.5 text-[11px] text-[var(--text)] outline-none focus:border-[var(--accent)]" />
                </Card>

                <Card title="Geometry">
                  <div className="grid grid-cols-2 gap-2">
                    <NumField label="X" value={node.x} onChange={(v) => update({ x: v })} />
                    <NumField label="Y" value={node.y} onChange={(v) => update({ y: v })} />
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-[11px] text-[var(--muted)]">Rotation {node.rot}°</span>
                    <button onClick={ed.rotateSelected}
                      className="rounded-md border border-[var(--border)] px-2 py-1 text-[10px] font-semibold text-[var(--text)] hover:border-[var(--accent)]">Rotate 90°</button>
                  </div>
                </Card>

                {isGate(node.type) && GATE_INFO[node.type].maxIn > 1 && (
                  <Card title="Inputs">
                    <div className="flex items-center gap-2">
                      <button disabled={node.inputs <= GATE_INFO[node.type as GateType].minIn}
                        onClick={() => update({ inputs: node.inputs - 1 })}
                        className="h-7 w-7 rounded-md border border-[var(--border)] text-[var(--text)] disabled:opacity-30">−</button>
                      <span className="w-8 text-center text-[13px] font-bold text-[var(--text)]">{node.inputs}</span>
                      <button disabled={node.inputs >= GATE_INFO[node.type as GateType].maxIn}
                        onClick={() => update({ inputs: node.inputs + 1 })}
                        className="h-7 w-7 rounded-md border border-[var(--border)] text-[var(--text)] disabled:opacity-30">+</button>
                      <span className="ml-auto text-[10px] text-[var(--muted)]">fan-in</span>
                    </div>
                  </Card>
                )}

                {node.type === 'CLOCK' && (
                  <Card title="Clock">
                    <NumField label="Period (ticks)" value={node.period ?? 12} onChange={(v) => update({ period: Math.max(2, v) })} />
                  </Card>
                )}

                <Card title="Signal state">
                  <PortStates node={node} ed={ed} sim={sim} />
                </Card>

                {isGate(node.type) && (
                  <Card title="Boolean evaluation">
                    <p className="text-[11px] leading-relaxed text-[var(--muted)]">{GATE_INFO[node.type].desc}</p>
                    <code className="mt-2 block rounded-md bg-[var(--panel2)] px-2 py-1.5 text-[11px] text-[var(--accent)]">
                      Y = {GATE_INFO[node.type].expr(Array.from({ length: node.inputs }, (_, i) => String.fromCharCode(65 + i)))}
                    </code>
                    <code className="mt-1.5 block rounded-md bg-[var(--panel2)] px-2 py-1.5 text-[11px] text-[var(--text)]">
                      {GATE_INFO[node.type].expr(
                        Array.from({ length: node.inputs }, (_, i) => {
                          const v = sim.nodeIn.get(inKey(node.id, i)) ?? 'X';
                          return v === 'X' ? 'Z' : String(v);
                        })
                      )} = {String(sim.nodeOut.get(outKey(node.id, 0)) ?? 'X').replace('X', 'Z')}
                    </code>
                  </Card>
                )}
              </>
            )}
          </>
        )}

        {tab === 'truth' && (
          <>
            {node && isGate(node.type) && (
              <Card title={`${node.type} truth table`}>
                <GateTable type={node.type} n={node.inputs} live={Array.from({ length: node.inputs }, (_, i) => sim.nodeIn.get(inKey(node.id, i)) ?? 'X')} />
              </Card>
            )}
            {!node && ctt && (
              <Card title="Circuit truth table">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-[10px]">
                    <thead>
                      <tr className="text-[var(--muted)]">
                        {ctt.switches.map((s) => <th key={s.id} className="border-b border-[var(--border)] px-1.5 py-1 font-semibold">{nodeTitle(s, doc.defs)}</th>)}
                        {ctt.probes.map((p) => <th key={p.id} className="border-b border-[var(--border)] bg-[var(--panel2)] px-1.5 py-1 font-semibold text-[var(--accent)]">{nodeTitle(p, doc.defs)}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {ctt.rows.map((r, i) => (
                        <tr key={i} className="text-center">
                          {r.ins.map((v, j) => <td key={j} className="px-1.5 py-0.5 text-[var(--text)]">{v}</td>)}
                          {r.outs.map((v, j) => <td key={j} className="px-1.5 py-0.5 font-bold" style={{ color: v === 1 ? 'var(--hi)' : v === 'X' ? 'var(--xx)' : 'var(--muted)' }}>{v === 'X' ? 'Z' : v}</td>)}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            )}
            {!node && !ctt && <Empty text="Add switches and probes (≤ 8 switches) to generate a circuit truth table, or select a single gate." />}
            {node && !isGate(node.type) && node.type !== 'CUSTOM' && <Empty text="Select a logic gate to view its truth table." />}
            {node && node.type === 'CUSTOM' && (
              <Card title="Component">
                <p className="text-[11px] text-[var(--muted)]">
                  {nodeTitle(node, doc.defs)} — hierarchical block with{' '}
                  {portCounts(node, doc.defs).ins} inputs / {portCounts(node, doc.defs).outs} outputs.
                </p>
              </Card>
            )}
          </>
        )}

        {tab === 'debug' && <Debug ed={ed} sim={sim} node={node} />}
      </div>
    </div>
  );
}

function PortStates({ node, ed, sim }: { node: CNode; ed: EditorAPI; sim: SimResult }) {
  const { ins, outs } = portCounts(node, ed.doc.defs);
  return (
    <div className="space-y-1">
      {Array.from({ length: ins }).map((_, i) => {
        const v = sim.nodeIn.get(inKey(node.id, i)) ?? 'X';
        const floating = sim.floating.includes(inKey(node.id, i));
        return (
          <div key={i} className="flex items-center gap-2 text-[11px]">
            <span className="w-14 text-[var(--muted)]">IN {i}</span>
            <Val_ v={v} />
            {floating && <span className="text-[10px] text-[var(--xx)]">floating</span>}
          </div>
        );
      })}
      {Array.from({ length: outs }).map((_, i) => (
        <div key={'o' + i} className="flex items-center gap-2 text-[11px]">
          <span className="w-14 text-[var(--muted)]">OUT {i}</span>
          <Val_ v={sim.nodeOut.get(outKey(node.id, i)) ?? 'X'} />
        </div>
      ))}
      {node.type === 'OUTPUT' && (
        <div className="flex items-center gap-2 text-[11px]">
          <span className="w-14 text-[var(--muted)]">READS</span>
          <Val_ v={sim.nodeIn.get(inKey(node.id, 0)) ?? 'X'} />
        </div>
      )}
    </div>
  );
}

function GateTable({ type, n, live }: { type: GateType; n: number; live: Val[] }) {
  const rows = gateTruthTable(type, n);
  const cur = live.map((v) => (v === 'X' ? null : v));
  return (
    <table className="w-full border-collapse text-[11px]">
      <thead>
        <tr className="text-[var(--muted)]">
          {Array.from({ length: Math.min(n, 4) }).map((_, i) => (
            <th key={i} className="border-b border-[var(--border)] px-2 py-1 font-semibold">{String.fromCharCode(65 + i)}</th>
          ))}
          <th className="border-b border-[var(--border)] bg-[var(--panel2)] px-2 py-1 font-semibold text-[var(--accent)]">Y</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => {
          const match = cur.every((c, j) => c === null || c === r.ins[j]) && !cur.includes(null);
          return (
            <tr key={i} className={`text-center ${match ? 'bg-[var(--accent)]/12' : ''}`}>
              {r.ins.map((v, j) => <td key={j} className="px-2 py-0.5 text-[var(--text)]">{v}</td>)}
              <td className="px-2 py-0.5 font-bold" style={{ color: r.out === 1 ? 'var(--hi)' : 'var(--muted)' }}>{r.out}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

function Debug({ ed, sim, node }: { ed: EditorAPI; sim: SimResult; node: CNode | null }) {
  const { doc } = ed;
  const issues: { level: 'warn' | 'err'; msg: string }[] = [];
  if (!sim.stable) issues.push({ level: 'err', msg: 'Circuit did not converge — possible oscillation in a feedback loop.' });
  sim.floating.forEach((k) => {
    const n = doc.nodes.find((x) => x.id === k.split(':')[0]);
    if (n) issues.push({ level: 'warn', msg: `${nodeTitle(n, doc.defs)} · input ${k.split(':')[2]} is floating (Z).` });
  });
  doc.nodes.filter((n) => n.type === 'CUSTOM' && !doc.defs.find((d) => d.id === n.defId))
    .forEach((n) => issues.push({ level: 'err', msg: `Missing definition for component ${n.id}.` }));

  // dependency trace for selected node
  const trace: { depth: number; label: string; val: Val }[] = [];
  if (node) {
    const seen = new Set<string>();
    const walk = (id: string, depth: number) => {
      if (depth > 6 || seen.has(id)) return;
      seen.add(id);
      const n = doc.nodes.find((x) => x.id === id);
      if (!n) return;
      trace.push({ depth, label: nodeTitle(n, doc.defs), val: sim.nodeOut.get(outKey(n.id, 0)) ?? 'X' });
      doc.wires.filter((w) => w.to.node === id).forEach((w) => walk(w.from.node, depth + 1));
    };
    walk(node.id, 0);
  }

  return (
    <>
      <Card title="Diagnostics">
        {!issues.length && <p className="text-[11px] text-[var(--hi)]">✓ No issues detected. Netlist is fully driven and stable.</p>}
        <div className="space-y-1">
          {issues.slice(0, 20).map((i, k) => (
            <div key={k} className="flex gap-2 rounded-md bg-[var(--panel2)] px-2 py-1.5 text-[10.5px] leading-snug">
              <span style={{ color: i.level === 'err' ? 'var(--xx)' : 'var(--muted)' }}>{i.level === 'err' ? '⨯' : '!'}</span>
              <span className="text-[var(--text)]">{i.msg}</span>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Engine">
        <Row k="Iterations" v={String(sim.iterations)} />
        <Row k="Converged" v={sim.stable ? 'true' : 'false'} />
        <Row k="Flat nodes" v={String(sim.values.size)} />
        <Row k="Nets" v={String(doc.wires.length)} />
      </Card>

      <Card title={node ? `Dependency trace · ${nodeTitle(node, doc.defs)}` : 'Dependency trace'}>
        {!node && <p className="text-[11px] text-[var(--muted)]">Select a node to trace its upstream signal path.</p>}
        {node && trace.map((t, i) => (
          <div key={i} className="flex items-center gap-2 py-0.5 text-[11px]" style={{ paddingLeft: t.depth * 12 }}>
            <span className="text-[var(--muted)]">{t.depth ? '└' : '●'}</span>
            <span className="text-[var(--text)]">{t.label}</span>
            <Val_ v={t.val} />
          </div>
        ))}
      </Card>
    </>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-xl border border-[var(--border)] bg-[var(--panel)] p-3">
      <h4 className="mb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-[var(--muted)]">{title}</h4>
      {children}
    </section>
  );
}

function Row({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2 py-0.5 text-[11px]">
      <span className="text-[var(--muted)]">{k}</span>
      <span className={`truncate text-[var(--text)] ${mono ? 'font-mono text-[10px]' : ''}`}>{v}</span>
    </div>
  );
}

function NumField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <span className="text-[10px] uppercase tracking-wider text-[var(--muted)]">{label}</span>
      <input type="number" value={value} onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full rounded-md border border-[var(--border)] bg-[var(--panel2)] px-2 py-1.5 text-[11px] text-[var(--text)] outline-none focus:border-[var(--accent)]" />
    </label>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <div className="rounded-xl border border-dashed border-[var(--border)] px-3 py-6 text-center text-[11px] text-[var(--muted)]">{text}</div>
  );
}
