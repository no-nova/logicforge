import { EditorAPI } from '../lib/store';
import { SimResult } from '../lib/circuit';
import { View } from './Canvas';

interface Props {
  ed: EditorAPI;
  sim: SimResult;
  running: boolean;
  setRunning: (v: boolean) => void;
  step: () => void;
  resetSim: () => void;
  tick: number;
  speed: number;
  setSpeed: (n: number) => void;
  view: View;
  setView: React.Dispatch<React.SetStateAction<View>>;
  fit: () => void;
  wireStyle: 'curve' | 'ortho';
  setWireStyle: (v: 'curve' | 'ortho') => void;
  snapOn: boolean;
  setSnapOn: (v: boolean) => void;
}

function B({ children, onClick, active, disabled, title, wide }: {
  children: React.ReactNode; onClick?: () => void; active?: boolean; disabled?: boolean; title?: string; wide?: boolean;
}) {
  return (
    <button onClick={onClick} disabled={disabled} title={title}
      className={`h-8 ${wide ? 'px-3' : 'px-2.5'} rounded-lg border text-[11px] font-semibold transition active:scale-95 disabled:opacity-30
        ${active
          ? 'border-[var(--accent)] bg-[var(--accent)] text-[var(--panel)]'
          : 'border-[var(--border)] bg-[var(--panel2)] text-[var(--text)] hover:border-[var(--accent)]'}`}>
      {children}
    </button>
  );
}

const Div = () => <div className="mx-1 h-6 w-px bg-[var(--border)]" />;

export default function Toolbar(p: Props) {
  const { ed, sim } = p;
  return (
    <div className="flex flex-wrap items-center gap-1.5 border-t border-[var(--border)] bg-[var(--panel)] px-3 py-2">
      <B onClick={() => p.setRunning(!p.running)} active={p.running} wide title="Run / pause simulation">
        {p.running ? '❚❚ Pause' : '▶ Run'}
      </B>
      <B onClick={p.step} title="Advance one tick" wide>⏭ Step</B>
      <B onClick={p.resetSim} title="Reset simulation state" wide>⟲ Reset</B>
      <div className="flex items-center gap-1.5 px-1">
        <span className="text-[10px] uppercase tracking-wider text-[var(--muted)]">Speed</span>
        <input type="range" min={1} max={20} value={p.speed} onChange={(e) => p.setSpeed(+e.target.value)}
          className="h-1 w-20 accent-[var(--accent)]" />
      </div>

      <Div />
      <B onClick={ed.undo} disabled={!ed.canUndo} title="Undo (⌘Z)">↩</B>
      <B onClick={ed.redo} disabled={!ed.canRedo} title="Redo (⌘⇧Z)">↪</B>
      <B onClick={ed.duplicateSelected} disabled={!ed.selection.length} title="Duplicate (⌘D)">⧉</B>
      <B onClick={ed.rotateSelected} disabled={!ed.selection.length} title="Rotate (R)">⟳</B>
      <B onClick={ed.deleteSelected} disabled={!ed.selection.length && !ed.selectedWires.length} title="Delete (⌫)">🗑</B>

      <Div />
      <B onClick={() => ed.alignSelected('left')} disabled={ed.selection.length < 2} title="Align left">⇤</B>
      <B onClick={() => ed.alignSelected('top')} disabled={ed.selection.length < 2} title="Align top">⇥</B>
      <B onClick={() => ed.alignSelected('vspace')} disabled={ed.selection.length < 2} title="Distribute vertically">⇕</B>
      <B onClick={() => ed.alignSelected('hspace')} disabled={ed.selection.length < 2} title="Distribute horizontally">⇔</B>
      <B onClick={() => p.setSnapOn(!p.snapOn)} active={p.snapOn} title="Snap to grid">#</B>
      <B onClick={() => p.setWireStyle(p.wireStyle === 'curve' ? 'ortho' : 'curve')} title="Wire routing style" wide>
        {p.wireStyle === 'curve' ? '∿ Curved' : '⌐ Ortho'}
      </B>

      <Div />
      <B onClick={() => p.setView((v) => ({ ...v, z: Math.max(0.2, v.z / 1.2) }))} title="Zoom out">−</B>
      <span className="w-12 text-center text-[11px] font-semibold text-[var(--muted)]">{Math.round(p.view.z * 100)}%</span>
      <B onClick={() => p.setView((v) => ({ ...v, z: Math.min(2.6, v.z * 1.2) }))} title="Zoom in">+</B>
      <B onClick={p.fit} title="Fit to view" wide>Fit</B>

      <div className="ml-auto flex items-center gap-3 pr-1 text-[10px] uppercase tracking-wider text-[var(--muted)]">
        <span>tick <b className="text-[var(--text)]">{p.tick}</b></span>
        <span>nodes <b className="text-[var(--text)]">{ed.doc.nodes.length}</b></span>
        <span>nets <b className="text-[var(--text)]">{ed.doc.wires.length}</b></span>
        <span className="flex items-center gap-1.5">
          <i className="inline-block h-2 w-2 rounded-full" style={{ background: sim.stable ? 'var(--hi)' : 'var(--xx)' }} />
          {sim.stable ? 'stable' : 'unstable'}
        </span>
      </div>
    </div>
  );
}
